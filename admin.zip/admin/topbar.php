<div class="topbar">
    <div class="search-box">
        <input type="text" placeholder="Search...">
    </div>
    <div class="profile">
        <img src="https://via.placeholder.com/40" alt="Profile">
        Admin Name
    </div>
</div>