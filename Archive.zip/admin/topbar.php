<div class="topbar">
    <div class="search-box">

    </div>
    <div class="profile" style="gap:20px;">
        <div class="profile">
            <img src="../img/user.png" alt="Profile">
            Admin
        </div>
        <a href="../logout.php" class="update-btn">Logout</a>
    </div>

</div>