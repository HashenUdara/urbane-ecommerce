<div class="sidebar">

    <img src="../img/urbane-nsh.png" />


    <ul>
        <li>
            <a href="./index.php">

                Dashboard
            </a>
        </li>
        <li>
            <a href="./orders.php">
                Orders
            </a>
            <a href="./products.php">
                Products
            </a>
        </li>
        <li>
            <a href="./users.php">
                Users
            </a>
        </li>
    </ul>
</div>