<header>
    <nav class="container">
        <a href="./index.php" style="text-decoration: none;">
            <div class="logo">Urbane</div>
        </a>

        <div class="nav-links">
            <a href="./index.php">Home</a>
            <a href="./shop.php">Collections</a>
            <a href="./cart.php">Cart</a>
            <a href="./order_history.php">Order History</a>
            <a href="./logout.php" class="btn" style=" color: #f4f4f4; ">Logout</a>
        </div>
    </nav>
</header>