<footer>
    <div class="container">
        <div class="footer-content">
            IS1207 Internet and Web Technologies - Final Group Project

        </div>
    </div>
</footer>

<?php
mysqli_close($conn);
